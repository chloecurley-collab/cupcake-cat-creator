export enum CupcakeFlavor {
  Chocolate = 'Chocolate Fudge',
  Strawberry = 'Strawberry Shortcake',
  VanillaSprinkle = 'Vanilla Sprinkle',
  Matcha = 'Matcha Green Tea',
  Blueberry = 'Blueberry Swirl',
  Rainbow = 'Rainbow Sherbet',
  Cosmic = 'Cosmic Galaxy',
  RedVelvet = 'Red Velvet',
  LemonMeringue = 'Lemon Meringue',
  Pistachio = 'Pistachio Delight',
  CoffeeCaramel = 'Coffee Caramel',
  MintChocolate = 'Mint Chocolate Chip',
  CoconutCream = 'Coconut Cream',
  LavenderHoney = 'Lavender Honey',
}

export interface Cupcake {
  flavor: CupcakeFlavor;
  emoji: string;
  color: string;
  textColor: string;
}

export enum FastFoodFlavor {
  Pizza = 'Pizza Slice',
  Burger = 'Cheeseburger',
  Fries = 'French Fries',
  Taco = 'Crunchy Taco',
  Hotdog = 'Classic Hotdog',
  Donut = 'Glazed Donut',
}

export interface FastFood {
  flavor: FastFoodFlavor;
  emoji: string;
  color: string;
  textColor: string;
}

export enum FruitFlavor {
  Apple = 'Crisp Apple',
  Banana = 'Sweet Banana',
  Watermelon = 'Juicy Watermelon',
  Orange = 'Zesty Orange',
  Grapes = 'Purple Grapes',
  Pineapple = 'Tropical Pineapple',
}

export interface Fruit {
  flavor: FruitFlavor;
  emoji: string;
  color: string;
  textColor: string;
}

export enum SmoothieFlavor {
  BerryBlast = 'Berry Blast',
  TropicalTango = 'Tropical Tango',
  GreenMachine = 'Green Machine',
  SunsetGlow = 'Sunset Glow',
  PeanutButterPower = 'Peanut Butter Power',
  ChocolateDream = 'Chocolate Dream',
}

export interface Smoothie {
  flavor: SmoothieFlavor;
  emoji: string;
  color: string;
  textColor: string;
}

export enum FancyFoodFlavor {
  Sushi = 'Sushi Roll',
  Macaron = 'French Macaron',
  Caviar = 'Black Caviar',
  Steak = 'Filet Mignon',
  Lobster = 'Lobster Thermidor',
  Truffle = 'Black Truffle Pasta',
}

export interface FancyFood {
  flavor: FancyFoodFlavor;
  emoji: string;
  color: string;
  textColor: string;
}


export type Food = Cupcake | FastFood | Fruit | Smoothie | FancyFood;
export type FoodCategory = 'cupcake' | 'fastFood' | 'fruit' | 'smoothie' | 'fancyFood';

export function getFoodCategory(food: Food): FoodCategory {
  if (Object.values(CupcakeFlavor).includes(food.flavor as CupcakeFlavor)) return 'cupcake';
  if (Object.values(FastFoodFlavor).includes(food.flavor as FastFoodFlavor)) return 'fastFood';
  if (Object.values(FruitFlavor).includes(food.flavor as FruitFlavor)) return 'fruit';
  if (Object.values(SmoothieFlavor).includes(food.flavor as SmoothieFlavor)) return 'smoothie';
  return 'fancyFood';
}