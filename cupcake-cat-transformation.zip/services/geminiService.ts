import { GoogleGenAI, Modality } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function urlToBase64(url: string): Promise<{base64: string, mime: string}> {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to fetch image from URL: ${url}`);
  }
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const base64 = dataUrl.split(',')[1];
      resolve({base64, mime: blob.type});
    };
    reader.readAsDataURL(blob);
  });
}

export async function generateCatName(flavors: string): Promise<string> {
  const prompt = `Generate one cool, cute, or punny name for a cat character inspired by the following foods: '${flavors}'. The name should be short and memorable. Return only the name as a single string, with no extra text, labels, or quotation marks.`;

  try {
     const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
     });
     return response.text.trim();
  } catch (e) {
    console.error("Error calling Gemini API for name generation:", e);
    return "Mysterious Mix"; // Fallback name
  }
}

export async function transformCat(
  base64ImageData: string,
  mimeType: string,
  flavor: string,
  catStyle: string
): Promise<string> {
  const prompt = `Transform this cat into a single, adorable cartoon character suitable for young children and babies. This new character should be creatively inspired by a MIX of the following food items: '${flavor}'. The cat should be depicted as ${catStyle}. The overall style should be very cute, with big, expressive, friendly eyes, a sweet smile, and simple, soft, rounded shapes. Blend the colors, textures, and whimsical elements from ALL the listed foods into one cohesive and imaginative design. The background should be a simple, cheerful pastel color. Please maintain the cat's original pose but render it in this charming, kid-friendly cartoon style.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return part.inlineData.data;
      }
    }

    throw new Error("The model did not return an image. It might have returned text explaining why. Check safety ratings.");
  } catch(e) {
    console.error("Error calling Gemini API:", e);
    throw new Error("Could not generate the cat image. Please try a different flavor.");
  }
}