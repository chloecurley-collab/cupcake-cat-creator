import React from 'react';

interface OvenProps {
  flavor: string | null;
}

const Oven: React.FC<OvenProps> = ({ flavor }) => {
  return (
    <div className="relative w-80 h-80 md:w-96 md:h-96 flex flex-col items-center justify-center p-4 transition-all duration-500 animate-fade-in">
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-2px); }
          20%, 40%, 60%, 80% { transform: translateX(2px); }
        }
        @keyframes glow {
          0%, 100% { box-shadow: 0 0 15px 5px rgba(255, 165, 0, 0.5); }
          50% { box-shadow: 0 0 30px 10px rgba(255, 165, 0, 0.8); }
        }
        @keyframes rise {
          0% { transform: translateY(0) scale(0); opacity: 1; }
          100% { transform: translateY(-80px) scale(1); opacity: 0; }
        }
        .animate-shake {
          animation: shake 0.82s cubic-bezier(.36,.07,.19,.97) both infinite;
        }
        .animate-glow {
          animation: glow 2s ease-in-out infinite;
        }
        .heart {
          animation: rise 2s ease-in-out infinite;
          position: absolute;
          font-size: 24px;
        }
      `}</style>
      
      <div className="relative w-72 h-64">
        {/* Hearts rising */}
        <div className="absolute top-0 left-1/2 w-full h-full">
            <span className="heart" style={{ left: '40%', animationDelay: '0s' }}>❤️</span>
            <span className="heart" style={{ left: '55%', animationDelay: '0.5s' }}>💖</span>
            <span className="heart" style={{ left: '45%', animationDelay: '1s' }}>❤️</span>
            <span className="heart" style={{ left: '60%', animationDelay: '1.5s' }}>💖</span>
        </div>

        {/* Oven Body */}
        <div className="w-full h-full bg-slate-300 rounded-2xl shadow-2xl border-4 border-slate-400 flex flex-col items-center justify-end p-4 animate-shake">
          {/* Oven Controls */}
          <div className="absolute top-4 w-full flex justify-center items-center gap-8">
            <div className="w-8 h-8 bg-slate-500 rounded-full border-2 border-slate-600"></div>
            <div className="w-10 h-10 bg-slate-500 rounded-full border-2 border-slate-600"></div>
            <div className="w-8 h-8 bg-slate-500 rounded-full border-2 border-slate-600"></div>
          </div>
          
          {/* Oven Door */}
          <div className="w-60 h-32 bg-slate-400 rounded-lg border-2 border-slate-500 flex items-center justify-center p-2 relative">
             <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-24 h-4 bg-slate-500 rounded-full"></div>
            {/* Window */}
            <div className="w-full h-full bg-gray-800 rounded-md overflow-hidden">
                <div className="w-full h-full animate-glow flex items-center justify-center">
                    <span className="text-4xl animate-bounce">🐱</span>
                </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 text-center text-slate-700">
        <p className="font-semibold text-lg">Baking a new friend...</p>
        {flavor && <p className="text-sm mt-1">Mixing: {flavor}</p>}
      </div>
    </div>
  );
};

export default Oven;
