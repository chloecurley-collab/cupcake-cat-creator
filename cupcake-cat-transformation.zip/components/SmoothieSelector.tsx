import React from 'react';
import { Smoothie } from '../types';

interface SmoothieSelectorProps {
  smoothies: Smoothie[];
  onSelect: (food: Smoothie) => void;
  isDisabled: boolean;
  isUnlocked: boolean;
  onUnlock: () => void;
}

const SmoothieSelector: React.FC<SmoothieSelectorProps> = ({ smoothies, onSelect, isDisabled, isUnlocked, onUnlock }) => {
  return (
    <div className="w-full bg-white/60 backdrop-blur-sm p-4 rounded-2xl shadow-lg">
      <h2 className="text-xl font-bold text-slate-700 mb-4">Super Smoothies</h2>
      {isUnlocked ? (
        <div className="flex flex-wrap justify-center gap-4">
          {smoothies.map((food) => (
            <button
              key={food.flavor}
              onClick={() => onSelect(food)}
              disabled={isDisabled}
              className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg shadow-md transition-all duration-200 transform hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-fuchsia-400 focus:ring-opacity-50 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none w-24 h-24 ${food.color} ${food.textColor}`}
              aria-label={`Select ${food.flavor}`}
            >
              <span className="text-4xl" role="img" aria-hidden="true">{food.emoji}</span>
              <span className="text-xs font-semibold text-center">{food.flavor}</span>
            </button>
          ))}
        </div>
      ) : (
        <div className="text-center p-4 bg-gray-200/50 rounded-lg">
          <p className="text-slate-600 mb-4">Unlock the Super Smoothies pack to add to your mix!</p>
          <button
            onClick={onUnlock}
            disabled={isDisabled}
            className="bg-fuchsia-500 text-white font-bold py-3 px-6 rounded-full shadow-lg hover:bg-fuchsia-600 transition-transform transform hover:scale-105 disabled:opacity-50"
          >
            Unlock Now ($0.99)
          </button>
        </div>
      )}
    </div>
  );
};

export default SmoothieSelector;
