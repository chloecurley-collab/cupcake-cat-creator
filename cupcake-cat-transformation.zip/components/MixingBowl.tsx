import React from 'react';
import { Food } from '../types';

interface MixingBowlProps {
  ingredients: Food[];
  onMix: () => void;
  onClear: () => void;
  isLoading: boolean;
}

const MAX_MIX_ITEMS = 3;

const MixingBowl: React.FC<MixingBowlProps> = ({ ingredients, onMix, onClear, isLoading }) => {
  return (
    <div className="w-full bg-white/60 backdrop-blur-sm p-4 rounded-2xl shadow-lg flex flex-col items-center gap-4">
      <h2 className="text-2xl font-bold text-slate-700">Mixing Bowl</h2>
      <div className="flex items-center justify-center gap-4 h-20">
        {Array.from({ length: MAX_MIX_ITEMS }).map((_, index) => {
          const ingredient = ingredients[index];
          return (
            <div
              key={index}
              className="w-16 h-16 bg-gray-200/50 rounded-full flex items-center justify-center text-3xl border-2 border-dashed border-gray-400"
            >
              {ingredient && (
                <span className="animate-fade-in" role="img" aria-label={ingredient.flavor}>
                  {ingredient.emoji}
                </span>
              )}
            </div>
          );
        })}
      </div>
      <div className="flex items-center gap-4 mt-2">
        <button
          onClick={onMix}
          disabled={isLoading || ingredients.length === 0}
          className="bg-purple-600 text-white font-bold py-3 px-6 rounded-full shadow-lg hover:bg-purple-700 transition-transform transform hover:scale-105 disabled:opacity-50 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Baking...' : 'Bake a Mix!'}
        </button>
        <button
          onClick={onClear}
          disabled={isLoading || ingredients.length === 0}
          className="bg-gray-500 text-white font-bold py-2 px-4 rounded-full shadow hover:bg-gray-600 transition-transform transform hover:scale-105 disabled:opacity-50"
        >
          Clear
        </button>
      </div>
    </div>
  );
};

export default MixingBowl;
