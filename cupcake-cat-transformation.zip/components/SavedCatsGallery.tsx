import React from 'react';

interface SavedCat {
  image: string;
  name: string;
}

interface SavedCatsGalleryProps {
  cats: SavedCat[];
}

const SavedCatsGallery: React.FC<SavedCatsGalleryProps> = ({ cats }) => {
  return (
    <div className="w-full bg-white/60 backdrop-blur-sm p-4 rounded-2xl shadow-lg mt-4">
      <h2 className="text-2xl font-bold text-slate-700 mb-4">My Saved Cats</h2>
      {cats.length === 0 ? (
        <p className="text-slate-500 text-center py-8">
          Your saved creations will appear here. Click the ❤️ on a cat to save it!
        </p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {cats.map((cat, index) => (
            <div key={index} className="relative rounded-lg overflow-hidden shadow-md bg-white p-1 aspect-square group">
              <img
                src={cat.image}
                alt={`Saved cat named ${cat.name}`}
                className="w-full h-full object-cover rounded"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs text-center p-1 font-semibold truncate transition-opacity opacity-0 group-hover:opacity-100">
                {cat.name}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SavedCatsGallery;