import React, { useState } from 'react';

const Header: React.FC = () => {
  const [copyText, setCopyText] = useState('Share');

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href).then(() => {
        setCopyText('Copied!');
        setTimeout(() => setCopyText('Share'), 2500);
      }).catch(err => {
        console.error('Failed to copy URL: ', err);
        alert('Failed to copy link.');
      });
    } else {
      alert('Clipboard API not available. Please copy the link manually.');
    }
  };
  
  return (
    <header className="relative w-full py-4">
      <div className="text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-slate-800 tracking-tight">
          Cupcake Cat Transformation
        </h1>
        <p className="mt-2 text-lg text-slate-600">
          What happens when a cat eats a cupcake? It becomes one!
        </p>
      </div>
      <button
        onClick={handleShare}
        style={{ minWidth: '110px' }}
        className="absolute top-4 right-0 bg-white text-purple-600 font-semibold py-2 px-4 rounded-full shadow-md hover:bg-purple-100 transition-all duration-300 flex items-center justify-center gap-2 transform hover:scale-105"
        aria-label="Share this app"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" />
        </svg>
        <span>{copyText}</span>
      </button>
    </header>
  );
};

export default Header;