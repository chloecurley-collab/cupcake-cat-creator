
import React from 'react';
import { INITIAL_CAT_IMAGE_URL } from '../constants';

interface CatDisplayProps {
  imageUrl: string;
  name: string | null;
  onSave: () => void;
  isSavable: boolean;
  isSaved: boolean;
}

const CatDisplay: React.FC<CatDisplayProps> = ({ imageUrl, name, onSave, isSavable, isSaved }) => {
  return (
    <div className="relative w-80 h-80 md:w-96 md:h-96 rounded-2xl shadow-2xl bg-white/60 backdrop-blur-sm flex items-center justify-center p-4 transition-all duration-500 overflow-hidden animate-fade-in">
        <>
          <img
            src={imageUrl}
            alt="A cat that looks like a cupcake"
            className="w-full h-full object-contain rounded-lg animate-fade-in"
          />
          {name && imageUrl !== INITIAL_CAT_IMAGE_URL && (
            <div className="absolute bottom-4 left-4 right-auto bg-black/50 text-white text-lg font-bold px-4 py-1 rounded-full shadow-lg animate-fade-in">
              {name}
            </div>
          )}
          {isSavable && (
            <button
              onClick={onSave}
              className="absolute bottom-4 right-4 bg-white text-pink-500 font-bold p-3 rounded-full shadow-lg hover:bg-pink-100 hover:text-pink-600 transition-all transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-pink-300"
              aria-label="Save this cat"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.636l1.318-1.318a4.5 4.5 0 116.364 6.364L12 20.364l-7.682-7.682a4.5 4.5 0 010-6.364z" />
              </svg>
            </button>
          )}
           {isSaved && (
            <div
              className="absolute bottom-4 right-4 text-pink-500 p-3 rounded-full shadow-lg bg-white"
              aria-label="Cat is saved"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </div>
          )}
        </>
    </div>
  );
};

export default CatDisplay;