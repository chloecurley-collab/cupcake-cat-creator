import React from 'react';
import { Cupcake } from '../types';

interface CupcakeSelectorProps {
  cupcakes: Cupcake[];
  onSelect: (cupcake: Cupcake) => void;
  isDisabled: boolean;
}

const CupcakeSelector: React.FC<CupcakeSelectorProps> = ({ cupcakes, onSelect, isDisabled }) => {
  return (
    <div className="w-full bg-white/60 backdrop-blur-sm p-4 rounded-2xl shadow-lg">
      <h2 className="text-xl font-bold text-slate-700 mb-4">Cupcakes</h2>
      <div className="flex flex-wrap justify-center gap-4">
        {cupcakes.map((cupcake) => (
          <button
            key={cupcake.flavor}
            onClick={() => onSelect(cupcake)}
            disabled={isDisabled}
            className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg shadow-md transition-all duration-200 transform hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-purple-400 focus:ring-opacity-50 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none w-24 h-24 ${cupcake.color} ${cupcake.textColor}`}
            aria-label={`Select ${cupcake.flavor} cupcake`}
          >
            <span className="text-4xl" role="img" aria-hidden="true">{cupcake.emoji}</span>
            <span className="text-xs font-semibold text-center">{cupcake.flavor}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default CupcakeSelector;