
import React, { useState, useCallback } from 'react';
import { Food, getFoodCategory } from './types';
import {
  CUPCAKES, FAST_FOODS, FRUITS, SMOOTHIES, FANCY_FOODS,
  INITIAL_CAT_IMAGE_URL,
  CUPCAKE_CAT_STYLES, FAST_FOOD_CAT_STYLES, FRUIT_CAT_STYLES, SMOOTHIE_CAT_STYLES, FANCY_FOOD_CAT_STYLES
} from './constants';
import { transformCat, urlToBase64, generateCatName } from './services/geminiService';

import Header from './components/Header';
import CatDisplay from './components/CatDisplay';
import ErrorDisplay from './components/ErrorDisplay';
import FastFoodSelector from './components/FastFoodSelector';
import SavedCatsGallery from './components/SavedCatsGallery';
import MixingBowl from './components/MixingBowl';
import FruitSelector from './components/FruitSelector';
import SmoothieSelector from './components/SmoothieSelector';
import FancyFoodSelector from './components/FancyFoodSelector';
import Oven from './components/Oven';
// FIX: Import the CupcakeSelector component.
import CupcakeSelector from './components/CupcakeSelector';

const MAX_MIX_ITEMS = 3;

interface SavedCat {
  image: string;
  name: string;
}

const App: React.FC = () => {
  const [catImage, setCatImage] = useState<string>(INITIAL_CAT_IMAGE_URL);
  const [catName, setCatName] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeFlavor, setActiveFlavor] = useState<string | null>(null);
  const [savedCats, setSavedCats] = useState<SavedCat[]>([]);
  const [mixIngredients, setMixIngredients] = useState<Food[]>([]);

  const [unlockedSections, setUnlockedSections] = useState({
    fastFood: false,
    fruits: false,
    smoothies: false,
    fancyFoods: false,
  });

  const handleUnlockSection = (section: keyof typeof unlockedSections) => {
    setUnlockedSections(prev => ({ ...prev, [section]: true }));
  };

  const handleAddToMix = useCallback((food: Food) => {
    if (mixIngredients.length < MAX_MIX_ITEMS) {
      setMixIngredients(prev => [...prev, food]);
    }
  }, [mixIngredients]);

  const handleClearMix = useCallback(() => {
    setMixIngredients([]);
  }, []);

  const handleMix = useCallback(async () => {
    if (mixIngredients.length === 0 || isLoading) return;

    setIsLoading(true);
    setError(null);
    setCatName(null);
    const combinedFlavor = mixIngredients.map(f => f.flavor).join(', ');
    setActiveFlavor(combinedFlavor);

    try {
      // Determine style based on the first ingredient's category
      const firstIngredient = mixIngredients[0];
      const category = getFoodCategory(firstIngredient);
      const styles = {
        cupcake: CUPCAKE_CAT_STYLES,
        fastFood: FAST_FOOD_CAT_STYLES,
        fruit: FRUIT_CAT_STYLES,
        smoothie: SMOOTHIE_CAT_STYLES,
        fancyFood: FANCY_FOOD_CAT_STYLES,
      }[category];

      const randomStyle = styles[Math.floor(Math.random() * styles.length)];

      const { base64, mime } = await urlToBase64(INITIAL_CAT_IMAGE_URL);
      
      // Generate image and name in parallel
      const [newBase64Image, newCatName] = await Promise.all([
        transformCat(base64, mime, combinedFlavor, randomStyle),
        generateCatName(combinedFlavor)
      ]);
      
      setCatImage(`data:image/png;base64,${newBase64Image}`);
      setCatName(newCatName);

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      setCatImage(INITIAL_CAT_IMAGE_URL);
      setCatName(null);
    } finally {
      setIsLoading(false);
      setActiveFlavor(null);
      setMixIngredients([]); // Clear ingredients after baking
    }
  }, [mixIngredients, isLoading]);

  const handleSaveCat = useCallback(() => {
    if (catImage && catName && !savedCats.some(c => c.image === catImage) && catImage !== INITIAL_CAT_IMAGE_URL) {
      setSavedCats(prevCats => [{ image: catImage, name: catName }, ...prevCats]);
    }
  }, [catImage, catName, savedCats]);

  const isSaved = savedCats.some(c => c.image === catImage);
  const isSavable = !isLoading && catImage !== INITIAL_CAT_IMAGE_URL && !isSaved;
  const isMixDisabled = isLoading || mixIngredients.length >= MAX_MIX_ITEMS;

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-start p-4 text-center font-sans">
       <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in {
          animation: fadeIn 0.5s ease-in-out;
        }
      `}</style>
      <div className="container mx-auto max-w-4xl">
        <Header />
        <main className="mt-8 w-full flex flex-col items-center gap-8">
          <ErrorDisplay message={error} />
          {isLoading ? (
            <Oven flavor={activeFlavor} />
          ) : (
            <CatDisplay
              imageUrl={catImage}
              name={catName}
              onSave={handleSaveCat}
              isSavable={isSavable}
              isSaved={isSaved}
            />
          )}
          <MixingBowl
            ingredients={mixIngredients}
            onMix={handleMix}
            onClear={handleClearMix}
            isLoading={isLoading}
          />
          <div className="w-full flex flex-col items-center gap-8">
            <CupcakeSelector
              cupcakes={CUPCAKES}
              onSelect={handleAddToMix}
              isDisabled={isMixDisabled}
            />
            <FastFoodSelector
              fastFoods={FAST_FOODS}
              onSelect={handleAddToMix}
              isDisabled={isMixDisabled}
              isUnlocked={unlockedSections.fastFood}
              onUnlock={() => handleUnlockSection('fastFood')}
            />
            <FruitSelector
              fruits={FRUITS}
              onSelect={handleAddToMix}
              isDisabled={isMixDisabled}
              isUnlocked={unlockedSections.fruits}
              onUnlock={() => handleUnlockSection('fruits')}
            />
            <SmoothieSelector
              smoothies={SMOOTHIES}
              onSelect={handleAddToMix}
              isDisabled={isMixDisabled}
              isUnlocked={unlockedSections.smoothies}
              onUnlock={() => handleUnlockSection('smoothies')}
            />
            <FancyFoodSelector
              fancyFoods={FANCY_FOODS}
              onSelect={handleAddToMix}
              isDisabled={isMixDisabled}
              isUnlocked={unlockedSections.fancyFoods}
              onUnlock={() => handleUnlockSection('fancyFoods')}
            />
          </div>
          <SavedCatsGallery cats={savedCats} />
        </main>
      </div>
    </div>
  );
};

export default App;