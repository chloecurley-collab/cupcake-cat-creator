import { Cupcake, CupcakeFlavor, FastFood, FastFoodFlavor, Fruit, FruitFlavor, Smoothie, SmoothieFlavor, FancyFood, FancyFoodFlavor } from './types';

export const CUPCAKES: Cupcake[] = [
  { flavor: CupcakeFlavor.Chocolate, emoji: '🍫', color: 'bg-yellow-900', textColor: 'text-white' },
  { flavor: CupcakeFlavor.Strawberry, emoji: '🍓', color: 'bg-pink-400', textColor: 'text-white' },
  { flavor: CupcakeFlavor.VanillaSprinkle, emoji: '🧁', color: 'bg-amber-100', textColor: 'text-amber-800' },
  { flavor: CupcakeFlavor.Matcha, emoji: '🍵', color: 'bg-green-400', textColor: 'text-green-900' },
  { flavor: CupcakeFlavor.Blueberry, emoji: '🫐', color: 'bg-indigo-400', textColor: 'text-white' },
  { flavor: CupcakeFlavor.Rainbow, emoji: '🌈', color: 'bg-gradient-to-r from-red-400 to-blue-400', textColor: 'text-white' },
  { flavor: CupcakeFlavor.Cosmic, emoji: '🌌', color: 'bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900', textColor: 'text-white' },
  { flavor: CupcakeFlavor.RedVelvet, emoji: '🍰', color: 'bg-red-700', textColor: 'text-white' },
  { flavor: CupcakeFlavor.LemonMeringue, emoji: '🍋', color: 'bg-yellow-200', textColor: 'text-yellow-800' },
  { flavor: CupcakeFlavor.Pistachio, emoji: '💚', color: 'bg-lime-300', textColor: 'text-lime-900' },
  { flavor: CupcakeFlavor.CoffeeCaramel, emoji: '☕', color: 'bg-amber-800', textColor: 'text-white' },
  { flavor: CupcakeFlavor.MintChocolate, emoji: '🌿', color: 'bg-teal-200', textColor: 'text-teal-900' },
  { flavor: CupcakeFlavor.CoconutCream, emoji: '🥥', color: 'bg-stone-200', textColor: 'text-stone-700' },
  { flavor: CupcakeFlavor.LavenderHoney, emoji: '🌸', color: 'bg-violet-300', textColor: 'text-violet-800' },
];

export const FAST_FOODS: FastFood[] = [
  { flavor: FastFoodFlavor.Pizza, emoji: '🍕', color: 'bg-red-500', textColor: 'text-white' },
  { flavor: FastFoodFlavor.Burger, emoji: '🍔', color: 'bg-amber-600', textColor: 'text-white' },
  { flavor: FastFoodFlavor.Fries, emoji: '🍟', color: 'bg-yellow-400', textColor: 'text-yellow-900' },
  { flavor: FastFoodFlavor.Taco, emoji: '🌮', color: 'bg-orange-400', textColor: 'text-orange-900' },
  { flavor: FastFoodFlavor.Hotdog, emoji: '🌭', color: 'bg-red-600', textColor: 'text-white' },
  { flavor: FastFoodFlavor.Donut, emoji: '🍩', color: 'bg-pink-300', textColor: 'text-pink-800' },
];

export const FRUITS: Fruit[] = [
  { flavor: FruitFlavor.Apple, emoji: '🍎', color: 'bg-red-400', textColor: 'text-white' },
  { flavor: FruitFlavor.Banana, emoji: '🍌', color: 'bg-yellow-300', textColor: 'text-yellow-800' },
  { flavor: FruitFlavor.Watermelon, emoji: '🍉', color: 'bg-green-500', textColor: 'text-white' },
  { flavor: FruitFlavor.Orange, emoji: '🍊', color: 'bg-orange-500', textColor: 'text-white' },
  { flavor: FruitFlavor.Grapes, emoji: '🍇', color: 'bg-purple-500', textColor: 'text-white' },
  { flavor: FruitFlavor.Pineapple, emoji: '🍍', color: 'bg-yellow-500', textColor: 'text-white' },
];

export const SMOOTHIES: Smoothie[] = [
  { flavor: SmoothieFlavor.BerryBlast, emoji: '🥤', color: 'bg-fuchsia-500', textColor: 'text-white' },
  { flavor: SmoothieFlavor.TropicalTango, emoji: '🍹', color: 'bg-orange-400', textColor: 'text-white' },
  { flavor: SmoothieFlavor.GreenMachine, emoji: '🥝', color: 'bg-lime-500', textColor: 'text-white' },
  { flavor: SmoothieFlavor.SunsetGlow, emoji: '🌅', color: 'bg-gradient-to-br from-orange-400 to-red-500', textColor: 'text-white' },
  { flavor: SmoothieFlavor.PeanutButterPower, emoji: '🥜', color: 'bg-amber-700', textColor: 'text-white' },
  { flavor: SmoothieFlavor.ChocolateDream, emoji: '🍫', color: 'bg-stone-700', textColor: 'text-white' },
];

export const FANCY_FOODS: FancyFood[] = [
  { flavor: FancyFoodFlavor.Sushi, emoji: '🍣', color: 'bg-teal-700', textColor: 'text-white' },
  { flavor: FancyFoodFlavor.Macaron, emoji: '🍬', color: 'bg-rose-300', textColor: 'text-rose-800' },
  { flavor: FancyFoodFlavor.Caviar, emoji: '⚫', color: 'bg-gray-800', textColor: 'text-white' },
  { flavor: FancyFoodFlavor.Steak, emoji: '🥩', color: 'bg-red-900', textColor: 'text-white' },
  { flavor: FancyFoodFlavor.Lobster, emoji: '🦞', color: 'bg-red-600', textColor: 'text-white' },
  { flavor: FancyFoodFlavor.Truffle, emoji: '🍄', color: 'bg-neutral-600', textColor: 'text-white' },
];


export const INITIAL_CAT_IMAGE_URL = 'https://i.imgur.com/3Z3QZ5C.png';

export const CUPCAKE_CAT_STYLES: string[] = [
  'a fluffy, cheerful cat with a swirly tail',
  'a sleek, elegant cat wearing a tiny crown',
  'a grumpy-faced cat that secretly loves sweets',
  'a playful kitten chasing sprinkles',
  'a majestic, long-haired cat with sparkling eyes',
  'a cartoon cat with big, round, innocent eyes',
  'a mischievous cat with a tiny wink',
  'a very chubby, round cat that looks sleepy',
  'a fancy cat wearing a small bow tie',
  'a curious cat peeking from behind the food',
  'a cat with oversized, adorable paws',
  'a happy cat with its tongue sticking out slightly',
  'a cat made of frosting and candy',
  'a magical cat with a glowing aura',
  'a tiny teacup kitten small enough to fit in a cupcake liner',
];

export const FAST_FOOD_CAT_STYLES: string[] = [
  'a cool cat wearing sunglasses',
  'a tough-looking cat with a leather jacket',
  'a silly cat with crossed eyes',
  'a cat enthusiastically about to take a huge bite',
  'a cat chef wearing a tiny chef hat',
  'a very relaxed cat, lounging lazily',
  'a superhero cat with a small cape',
  'a goofy cat balancing food on its head',
  'a hungry cat with a very wide mouth',
  'a cat driving a tiny red convertible',
  'a punk rock cat with a mohawk',
  'a cat acting as a waiter with a tiny tray',
  'a cat looking very satisfied after a meal',
  'a cat popping out of a burger bun',
  'a streetwise cat with a cool bandana',
];

export const FRUIT_CAT_STYLES: string[] = [
  'a sweet-faced cat with a leaf on its head',
  'a cat happily hiding inside a fruit basket',
  'a cat with a round body like a berry',
  'a cat with a peel-like pattern on its back',
  'a sunny and bright cat with a cheerful grin',
  'a cat with seed-like spots on its fur',
  'a cat wearing a fruit slice as a hat',
  'a cat with a juicy, glossy-looking coat',
  'a cat peacefully napping under a fruit tree',
  'a zesty cat with energetic, pointy ears',
  'a cat that looks fresh and healthy',
  'a tiny cat climbing a giant piece of fruit',
  'a cat with a stem and leaf for a tail',
  'a tropical-themed cat with floral patterns',
  'a cat that looks like a freshly picked fruit',
];

export const SMOOTHIE_CAT_STYLES: string[] = [
  'a cat with a swirly, blended fur pattern',
  'a cat with different colored layers like a smoothie',
  'a cat wearing a tiny umbrella and a straw',
  'a very energetic and vibrant cat',
  'a cat that looks cool and refreshing',
  'a cat with fruit pieces as accessories',
  'a cat with a creamy, soft-looking texture',
  'a cat chilling in a giant smoothie cup',
  'a cat with a splash of color on its tail',
  'a cat with a healthy and glowing appearance',
  'a cat that looks like liquid in motion',
  'a sweet cat with a dollop of whipped cream on its head',
  'a tropical cat with a flower behind its ear',
  'a cat with a frosty, chilled look',
  'a cat that seems to be bursting with energy',
];

export const FANCY_FOOD_CAT_STYLES: string[] = [
  'a very sophisticated cat with a monocle',
  'an elegant cat wearing a tuxedo',
  'a cat dining at a fancy restaurant',
  'a cat with a very refined and delicate appearance',
  'a cat that looks expensive and rare',
  'a cat with a perfectly groomed, pristine coat',
  'a cat holding a tiny, fancy fork and knife',
  'a cat with gold flakes or edible flowers in its fur',
  'a poised and graceful cat with a royal demeanor',
  'a cat that looks like a culinary masterpiece',
  'a cat with a minimalist and artistic design',
  'a cat lounging on a velvet cushion',
  'a cat that looks like it belongs in a palace',
  'a cat with a garnish, like a sprig of parsley',
  'a cat with an air of mystery and luxury',
];